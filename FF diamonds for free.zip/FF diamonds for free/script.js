document.getElementById('diamondForm').addEventListener('submit', function(event) {
    event.preventDefault();

    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;

    // Here you can add your logic for processing the email and password
    // For demonstration, we'll just show a message
    document.getElementById('message').innerText = `Diamonds will be sent to ${email} if credentials are valid.`;
    
    // Reset form fields
    this.reset();
});
